jQuery 1.11.0 & jQuery 2.0.1
============================

Site
----
	http://jquery.com/download/