Library
=======

Pasta para bibliotecas e frameworks como jquery, bootstrap entre outras.