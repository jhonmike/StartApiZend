<?php
return array();
// return array(
//     'doctrine' => array(
//         'connection' => array(
//             // default connection name
//             'orm_default' => array(
//                 'doctrine_type_mappings' => array(
//                     'enum' => 'string'
//                 ),
//                 'driverClass' => 'Doctrine\DBAL\Driver\PDOMySql\Driver',
//                 'params' => array(
//                     'host'     => 'localhost',
//                     'port'     => '3306',
//                     'user'     => 'root',
//                     'password' => '',
//                     'dbname'   => 'zf2app_',
//                     'driverOptions' => array(
//                         PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'UTF8'"
//                     )
//                 )
//             )
//         )
//     ),
// );
